# Current research delivery and reproduction entry

Updated 2026-10-09. This is the current extension status; the 2026-10-07
submission-readiness notes describe the earlier frozen manuscript. Their statement
that no computation remained does not describe the present factorial extension.

## Current scientific deliverable

The editable manuscript is [innovation-addendum-v1.tex](paper/innovation-addendum-v1.tex).
It now defines the data cohorts, advertised-price target, stochastic outcome
metrics and unilateral audits. It is a working addendum, not a finalized submission.
The editor compiler successfully checked this source after the latest edit.

Candidate contributions are the precision frontier under explicit information
and accuracy constraints, auditable verification-path decomposition, and a
controlled study of heterogeneous effects. LPs, randomization, water filling and
the minimum operator are established tools. The fixed-mixture separation is
restricted: a context-aware library can close it. No universal superiority or
first-result claim is justified by the current evidence.

## Reproduction map

Run from this project directory in the scientific environment and use fresh
output paths. Do not restart an existing live producer or alter its bound sources.

| Component | Instructions | Verified receipt |
|---|---|---|
| Finite observable-report oracle | [oqbo-val/README.md](oqbo-val/README.md) | [independently_audited_finite_oracle](oqbo-val/outputs/finite-demo-01-audit-01/completion.json) |
| Compact marginal oracle | [oqbo-val/REPRODUCING-COMPACT.md](oqbo-val/REPRODUCING-COMPACT.md) | [completed](oqbo-val/outputs/compact-v1-audit/completion.json) |
| Restricted fixed-mixture separation | [oqbo-val/README.md](oqbo-val/README.md) | [completed](oqbo-val/outputs/context-mixture-gap-v1/completion.json) |
| Context-aware library closes the separation | [oqbo-val/README.md](oqbo-val/README.md) | [completed](oqbo-val/outputs/context-rule-library-v1/completion.json) |
| Conditional stability checks | [REPRODUCING_STABILITY.md](REPRODUCING_STABILITY.md) | [completed_exact_finite_checks](oqbo-val/outputs/score-stability-v1/completion.json) |
| Saved-profile stability check | [REPRODUCING_STABILITY.md](REPRODUCING_STABILITY.md) | [completed](outputs/allocation-stability-full-v1-check/completion.json) |
| Original ten-seed statistics check | [REPRODUCING.md](REPRODUCING.md) | [completed](outputs/ten-seed-three-source-union-v1-statistics-check/completion.json) |
| Frozen-model allocation statistics check | [REPRODUCING.md](REPRODUCING.md) | [completed](outputs/minimax-response-full-v1-statistics-check/completion.json) |

The original-study guide does not by itself reproduce every extension. For the
controlled factorial, use [REPRODUCING_MATCHED_FACTORIAL.md](REPRODUCING_MATCHED_FACTORIAL.md);
its automatic handoff is the active route. Saved receipts and their hashes are
indexed in [the delivery snapshot](notes/current-delivery-evidence-v1.json).
Receipts verify the documented scope, not every optimizer step or scientific novelty.

## Running work and release gate

At this snapshot, 14/30 source/seed pairs have completed fit and evaluation.
This is not a performance analysis of the partial run. Two future MUCars fits
run alongside the main producer using the unchanged scientific fitting routine.
The resource guard supervises them and records an internal summary on termination.
Its reclaimable-memory threshold is a protective policy, not a hard reservation.

The active pipeline at `outputs/matched-factorial-ten-seeds-v1-pipeline` waits
for the verified producer, then runs full fit audit, outcome audit, contrast
analysis and independent statistics check. Results may enter the manuscript
only after all four stages finish with valid bindings and complete coverage.
All contrast directions, failures and nonconverged responses must remain visible.

## Work needed for the user's full goal

1. Complete the factorial and all four verification stages; explain source and
   method interactions rather than selecting favorable cells.
2. Integrate checked results, practical guidance and figures into one submission
   manuscript; inspect the final rendered layout and references.
3. Complete a clean-environment reproduction and a current evidence package.
   Historical archives do not contain every new component. Public release,
   software licensing and a repository/DOI remain unresolved.
4. Confirm the institution's meaning of “三区” and the target journal's current
   requirements. The earlier Scientific Reports screening is conditional, not
   proof of an applicable institutional classification.
5. Finalize corresponding author, contributions, funding, conflicts and author
   approval, including the AI assistance disclosure. These cannot be invented.

The full goal is still in progress. Completion of computation alone does not
mean submission readiness or journal acceptance.
