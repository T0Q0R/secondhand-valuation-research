# 分区与投稿说明核对：2026-10-07

当前仍为条件候选Scientific Reports；本注不证明用户单位的认可政策、期刊接受或投稿完成。

## 新的公开分区证据

浙大宁波理工学院图书馆公开检索记录列Scientific Reports（ISSN2045-2322）
2025年MULTIDISCIPLINARY SCIENCES为Q1；记录编号NBT-SCIE-2026-17065-IF2025，
页面显示检索日期2026-10-07。此来源不是用户本校分区制度；不能据此把该刊当成JCRQ3。
https://lib.nbt.edu.cn/subject/indexed/paper_print.php?sid=17065&son=if&whatdb=scie

浙江师范大学STEM教育研究中心介绍（页面日期2026-02-20）列该刊2025年
中科院综合类3区及JCRQ1。此类期刊介绍是筛选证据，不是本校适用的认证分区表。
其影响因子文字与图书馆记录不同，不将不同日期/口径的数值混用，也不据此选刊。
https://stem.zjnu.edu.cn/2026/0227/c9134a547475/page.htm

检索未取得南京理工大学紫金学院适用的公开分区制度；官方网站页面工具不可访问。
这只说明本次未获取，不证明制度不存在。未登录或绕过权限/CAPTCHA。
三区口径已通过简短问题向用户澄清；原规模实验继续独立执行。

## AI声明位置

当前官方投稿说明要求在Methods说明LLM使用（缺少Methods才用其他合适部分）。
把已存在的真实Codex辅助声明移入期刊Methods，并在完整技术稿的Experimental
Setup保留同一段内容；删除DataAvailability中的重复。声明内容不变，不伪造真人审阅。
https://www.nature.com/srep/author-instructions/submission-guidelines

当前AI政策强调透明声明与人类责任；已有声明明确算法/代码/审计/稿件辅助和
作者审阅待完成。未把工具列为作者，也未声称科学判断已获得真人批准。
https://www.nature.com/srep/journal-policies/ai

当前投稿checklist直接访问重定向至身份页面并失败；不将该失败解释为确认了
全部强制要求或新页数限制。此前官方指南的理想11页说明仍不被写成硬性上限。

## 已供作者信息

外层记录已有人类提供作者顺序及共同单位/联系邮箱。按用户要求，不重复制作
或索取作者确认表；本注也不自行补通讯作者身份、英文姓名批准或实际贡献。
本轮仅做可逆本地稿件调整与公开资料阅读，无上传、投稿、编辑联系或付款。
